#include "projeto.h"

static GtkWidget* time_sequencial,* time_encadeado,* number1;
TlistaEnc listaEnc ;
int num1;

void calcular_tempo (int T,char auxiliar[20]){
  int hor,min,seg,b;
  char h[10],m[10],s[10],t[10];

  hor =  T / 3600;
  b = T - ( hor * 3600);
  min =  b / 60;
  seg =  b - (min * 60);

  sprintf(h, "%i", hor);
  sprintf(m, "%i", min);
  sprintf(s, "%i", seg);

  if(hor < 10 || hor == 0){
  	auxiliar[0] ='0';
  	auxiliar[1] = h[0];
  }

  else{
  	auxiliar[0] = h[0];
  	auxiliar[1] = h[1];
  }

  auxiliar[2] = ' ';
  auxiliar[3] = ':';
  auxiliar[4] = ' ';

  if(min < 10){
    auxiliar[5] = '0';
    auxiliar[6] = m[0];
  }

  else {
    auxiliar[5] = m[0];
    auxiliar[6] = m[1];
  }

  auxiliar[7] = ' ';
  auxiliar[8] = ':';
  auxiliar[9] = ' ';

  if (seg < 10){
    auxiliar[10] = '0';
    auxiliar[11] = s[0];
  }

  else {
    auxiliar[10] = s[0];
    auxiliar[11] = s[1];
  }

  auxiliar[12] = '\0';

}

void gerar_numeros (GtkWidget* boton1, gpointer data){
  num1 = atoi((char *)gtk_entry_get_text(GTK_ENTRY(number1)));
  
  unsigned long int i;
  FILE *arquivo;
  arquivo = fopen("aleatorios.txt", "w");
  if(arquivo == NULL){
      printf("Arquivo nao pode ser aberto.\n");
      return;
  }

  if(listaEnc.lista != NULL){
    apagar_lista_encadeada(&listaEnc);
  }
  srand( (unsigned) time(NULL));
  int num;
  for(i=0; i<num1; i++){
    num = 1 + rand() % (num1 * 2);
    fprintf(arquivo, "%d ", num);   
  }
  
  fclose(arquivo);
}

void adicionar_encadeado(TlistaEnc* l){
  int valor;; 
  unsigned long int i,y;
  printf("cheguei aqui\n");
 
  FILE *arquivo1;
  arquivo1 = fopen("aleatorios.txt","r");
  if (arquivo1 == NULL) {
      printf("Arquivo nao pode ser aberto.\n");
      return;
  }
  int num;
  for (i=0;i<num1;i++){
    fscanf(arquivo1,"%d",&valor);
    add(&listaEnc,valor);
  }
  
  fclose(arquivo1);
  imprimir(listaEnc);
}

void ordenar_encadeado (GtkWidget* boton1, gpointer data){
  unsigned long int i;
  FILE *arquivo;
  clock_t Inicio, Fim;

  printf("deu pau;\n");
  adicionar_encadeado(&listaEnc);

  arquivo = fopen("ordenado.txt", "w");
  if(arquivo == NULL){
      printf("Arquivo nao pode ser aberto.\n");
      return;
  }

  srand( (unsigned) time(NULL));
  int num;

  Inicio = clock();
  HeapSort(&listaEnc, listaEnc.size);
  Fim = clock();
  
  no* aux = listaEnc.lista;
  while(aux != NULL){
    fprintf(arquivo, "%d ", aux -> dado); 
    aux = aux -> prox;
  }
  fclose(arquivo);
  imprimir(listaEnc);

  float tempo_final = (Fim - Inicio) / 1000000;
  char buffer[20];
  char tempo_encadeado[20];
  calcular_tempo(tempo_final,tempo_encadeado);
  
  snprintf(buffer, sizeof(buffer), "%s",tempo_encadeado);
  gtk_label_set_text(GTK_LABEL(time_encadeado), buffer);

}

int main(int argc, char **argv){

  inicializar(&listaEnc);

  GtkWidget * window,* grid,* boton1,* boton2,* boton3, * conteudo;

  gtk_init(&argc, &argv);

  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);
  gtk_container_set_border_width (GTK_CONTAINER (window), 10);
  gtk_window_set_title (GTK_WINDOW (window), "Programa");


  grid = gtk_grid_new();
  gtk_container_add(GTK_CONTAINER(window), grid);
  gtk_grid_set_row_spacing(GTK_GRID(grid),2.5);
  gtk_grid_set_column_spacing (GTK_GRID(grid),2.5);

  number1 = gtk_entry_new();
  gtk_grid_attach(GTK_GRID(grid), number1, 0, 0, 1, 1);

  boton1 = gtk_button_new_with_label("Gerar números aleatórios");
  g_signal_connect(boton1, "clicked", G_CALLBACK(gerar_numeros), NULL);
  gtk_grid_attach(GTK_GRID(grid), boton1, 1, 0, 1, 1);

  boton2 = gtk_button_new_with_label("Ordenar com lista encadeada");
  g_signal_connect(boton2, "clicked", G_CALLBACK(ordenar_encadeado), NULL);
  gtk_grid_attach(GTK_GRID(grid), boton2, 0, 1, 1, 1);

  boton3 = gtk_button_new_with_label("Ordenar com lista sequencial");
  g_signal_connect(boton3, "clicked", G_CALLBACK(gerar_numeros), NULL);
  gtk_grid_attach(GTK_GRID(grid), boton3, 1, 1, 1, 1);

  time_encadeado = gtk_label_new("TEMPO ENCADEADO");
  gtk_grid_attach(GTK_GRID(grid), time_encadeado, 0, 2, 1, 1);

  time_sequencial = gtk_label_new("TEMPO SEQUENCIAL");
  gtk_grid_attach(GTK_GRID(grid), time_sequencial, 1, 2, 1, 1);

  gtk_widget_show_all(window);
  gtk_main();

  return 0;

}