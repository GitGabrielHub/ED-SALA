#include "heap_sequencial.h"


void trocarElementosSequencial(int vet[], int posicaoMenor, int posicaoMaior){
  
  int aux = vet[posicaoMaior];
  vet[posicaoMaior] = vet[posicaoMenor];
  vet[posicaoMenor] = aux;

}


void HeapSortSequencial(int vet[], int tamanho){

  for(int i = tamanho/2 - 1 ;i >= 0 ; i--){
    ordenarSequencial(vet, tamanho, i);
  }

  for(int i = tamanho-1; i>=0; i--){
    trocarElementosSequencial(vet, i, 0);
    ordenarSequencial(vet, i, 0);
  }

}

void ordenarSequencial(int vet[], int tamanho, int maiorElemento){

  int raiz = maiorElemento;
  int filhoEsquerdo = 2*maiorElemento + 1;
  int FilhoDireita = 2*maiorElemento + 2;

  if(filhoEsquerdo < tamanho && vet[filhoEsquerdo] > vet[raiz]) raiz = filhoEsquerdo;

  if(FilhoDireita < tamanho && vet[FilhoDireita] > vet[raiz]) raiz = FilhoDireita;

  if (raiz != maiorElemento){

    trocarElementosSequencial(vet, raiz, maiorElemento);

    ordenarSequencial(vet, tamanho, raiz);

  }



}

void imprimirSequencial(int vet[], int tamanho){

  printf("HEAPSORT ARRAY [ ");
  for(int i = 0; i < tamanho; i++){
    printf("%d ", vet[i]);
  }
  printf("]\n");
  printf("tamanho : %d\n", tamanho);
}

int verificarOrdenacao_sequencial(int vet[], int tamanho){
  for(int i = 1; i < tamanho; i++){
    if(vet[i-1] > vet[i]) return false;
  }

  return true;
}

bool iniciarVetor(TVet *vet, int tamanho){
  
 if (vet->vetor == NULL){
  int *pI;
  if ((pI = (int*)malloc(tamanho*sizeof(int))) == NULL) return false;


  vet->vetor = pI;
  vet->tamanho = tamanho;


 }else if(tamanho != vet->tamanho){
   free(vet->vetor);
   vet->tamanho = tamanho;

   int *pI;
   if ((pI = (int*)malloc(tamanho*sizeof(int))) == NULL) return false;

  vet->vetor = pI;
 }
  
 return true;
   
}

void inicializarSequencial(TVet* vetor){
  vetor->vetor = NULL;
}