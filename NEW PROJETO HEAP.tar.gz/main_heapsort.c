#include "projeto.h"
#include "heap_sequencial.h"

static GtkWidget* time_sequencial,* time_encadeado,* number1;
TlistaEnc listaEnc ;
TVet vetor;

int num1;

void calcular_tempo (int T,char auxiliar[40]){
  char nano[25];
  char us[20];
  strcpy(us," Microssegundos");
  if (T  / 1000000 < 1){
  	sprintf(nano, "%d", T);

  	int i;
  	for (i = 0; nano[i] != '\0'; i++){
  		auxiliar[i] = nano[i];
  	}
  	int j;
  	for(j = 0; us[j] != '\0'; j++,i++){
  		auxiliar[i] = us[j];
  	}
  	auxiliar[i] = '\0';
 
  	return;
  }
  char hms[20];
  strcpy(auxiliar,"H  : M  : S\n");

  T = T  / 1000000;

  int hor,min,seg,b;
  char h[10],m[10],s[10],t[10];

  hor =  T / 3600;
  b = T - ( hor * 3600);
  min =  b / 60;
  seg =  b - (min * 60);

  sprintf(h, "%i", hor);
  sprintf(m, "%i", min);
  sprintf(s, "%i", seg);

  if(hor < 10 || hor == 0){
  	auxiliar[12] ='0';
  	auxiliar[13] = h[0];
  }

  else{
  	auxiliar[12] = h[0];
  	auxiliar[13] = h[1];
  }

  auxiliar[14] = ' ';
  auxiliar[15] = ':';
  auxiliar[16] = ' ';

  if(min < 10){
    auxiliar[17] = '0';
    auxiliar[18] = m[0];
  }

  else {
    auxiliar[17] = m[0];
    auxiliar[18] = m[1];
  }

  auxiliar[19] = ' ';
  auxiliar[20] = ':';
  auxiliar[21] = ' ';

  if (seg < 10){
    auxiliar[22] = '0';
    auxiliar[23] = s[0];
  }

  else {
    auxiliar[22] = s[0];
    auxiliar[23] = s[1];
  }

  auxiliar[24] = '\0';

}

void gerar_numeros (GtkWidget* boton1, gpointer data){
  num1 = atoi((char *)gtk_entry_get_text(GTK_ENTRY(number1)));
  
  unsigned long int i;
  FILE *arquivo;
  arquivo = fopen("aleatorios.txt", "w");
  if(arquivo == NULL){
      printf("Arquivo nao pode ser aberto.\n");
      return;
  }

  if(listaEnc.lista != NULL){
    apagar_lista_encadeada(&listaEnc);
  }

  int valor;
  for(i=0; i<num1; i++){
    valor = 1 + rand() % (num1 * 3);
    fprintf(arquivo, "%d ", valor);   
  }
  
  fclose(arquivo);
}

void adicionar_encadeado(TlistaEnc* l){
  int valor;
  unsigned long int i;
 
  FILE *arquivo1;
  arquivo1 = fopen("aleatorios.txt","r");
  if (arquivo1 == NULL) {
      printf("Arquivo nao pode ser aberto.\n");
      return;
  }
  for (i=0;i<num1;i++){
    fscanf(arquivo1,"%d",&valor);
    add(&listaEnc,valor);
  }
  
  fclose(arquivo1);
  //imprimir(listaEnc);
}

void adicionar_txt_encadeado(TlistaEnc* l){
  	FILE *arquivo;
  	arquivo = fopen("ordenado_encadeado.txt", "w");
  	if(arquivo == NULL){
  		printf("Arquivo nao pode ser aberto.\n");
      	return;
  	}
  	no* aux = l->lista;
  	while(aux != NULL){
    	fprintf(arquivo, "%d ", aux -> dado); 
    	aux = aux -> prox;
  	}
  	fclose(arquivo);
}

void ordenar_encadeado (GtkWidget* boton2, gpointer data){
  
  clock_t Inicio, Fim;

  adicionar_encadeado(&listaEnc);

  Inicio = clock();
  HeapSort(&listaEnc, listaEnc.size);
  Fim = clock();

  adicionar_txt_encadeado(&listaEnc);

  float tempo_final = (Fim - Inicio);
  char buffer[40];
  char tempo_encadeado[40];
  calcular_tempo(tempo_final,tempo_encadeado);
  
  snprintf(buffer, sizeof(buffer), "%s",tempo_encadeado);
  gtk_label_set_text(GTK_LABEL(time_encadeado), buffer);

}

void adicionar_sequencial (TVet* vetor){
	unsigned long int i;
	 
	FILE *arquivo1;
	arquivo1 = fopen("aleatorios.txt","r");
	if (arquivo1 == NULL) {
		printf("Arquivo nao pode ser aberto.\n");
	    return;
	}
	int num,valor;
	for (i=0;i<vetor->tamanho;i++){
		fscanf(arquivo1,"%d",&valor);
		vetor->vetor[i] = valor;
	}

	fclose(arquivo1);

}

void adicionar_txt_sequencial(TVet* vetor){
	unsigned long int i;
	 
	FILE *arquivo1;
	arquivo1 = fopen("ordenado_sequencial.txt","w");
	if (arquivo1 == NULL) {
		printf("Arquivo nao pode ser aberto.\n");
	    return;
	}
	int num,valor;
	for (i=0;i<vetor->tamanho;i++){
		fprintf(arquivo1, "%d ", vetor->vetor[i]); 
	}

	fclose(arquivo1);
}

void ordenar_sequencial (GtkWidget* boton3, gpointer data){
	if ( (iniciarVetor(&vetor,num1)) == true) printf("Iniciado com sucesso\n");
	adicionar_sequencial(&vetor);
	clock_t Inicio, Fim;
	
	Inicio = clock();
 	HeapSortSequencial(vetor.vetor,vetor.tamanho);
  	Fim = clock();

	float tempo_final = (Fim - Inicio);
	char buffer[40];
	char tempo_sequencial[40];
	calcular_tempo(tempo_final,tempo_sequencial);
		  
	snprintf(buffer, sizeof(buffer), "%s",tempo_sequencial);
	gtk_label_set_text(GTK_LABEL(time_sequencial), buffer);

	adicionar_txt_sequencial(&vetor);
	//imprimirSequencial(vetor.vetor,vetor.tamanho);

}

int main(int argc, char **argv){

  inicializar(&listaEnc);
  inicializarSequencial(&vetor);

  GtkWidget * window,* grid,* boton1,* boton2,* boton3, * conteudo;

  gtk_init(&argc, &argv);

  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);
  gtk_container_set_border_width (GTK_CONTAINER (window), 10);
  gtk_window_set_title (GTK_WINDOW (window), "Programa");

  grid = gtk_grid_new();
  gtk_container_add(GTK_CONTAINER(window), grid);
  gtk_grid_set_row_spacing(GTK_GRID(grid),2.5);
  gtk_grid_set_column_spacing (GTK_GRID(grid),2.5);

  number1 = gtk_entry_new();
  gtk_grid_attach(GTK_GRID(grid), number1, 0, 0, 1, 1);

  boton1 = gtk_button_new_with_label("Gerar números aleatórios");
  g_signal_connect(boton1, "clicked", G_CALLBACK(gerar_numeros), NULL);
  gtk_grid_attach(GTK_GRID(grid), boton1, 1, 0, 1, 1);

  boton2 = gtk_button_new_with_label("Ordenar com lista encadeada");
  g_signal_connect(boton2, "clicked", G_CALLBACK(ordenar_encadeado), NULL);
  gtk_grid_attach(GTK_GRID(grid), boton2, 0, 1, 1, 1);

  boton3 = gtk_button_new_with_label("Ordenar com lista sequencial");
  g_signal_connect(boton3, "clicked", G_CALLBACK(ordenar_sequencial), NULL);
  gtk_grid_attach(GTK_GRID(grid), boton3, 1, 1, 1, 1);

  time_encadeado = gtk_label_new("TEMPO ENCADEADO");
  gtk_grid_attach(GTK_GRID(grid), time_encadeado, 0, 2, 1, 1);

  time_sequencial = gtk_label_new("TEMPO SEQUENCIAL");
  gtk_grid_attach(GTK_GRID(grid), time_sequencial, 1, 2, 1, 1);

  gtk_widget_show_all(window);
  gtk_main();

  return 0;

}