#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
#include <string.h>

typedef struct vetor{

  int *vetor;
  int tamanho;

}TVet;

void HeapSortSequencial(int vet[], int tamanho);
void ordenarSequencial(int vet[], int tamanho, int maiorElemento);
void trocarElementosSequencial(int vet[], int posicaoMenor, int posicaoMaior);
void imprimirSequencial(int vet[], int tamanho);
int verificarOrdenacao(int vet[], int tamanho);
bool iniciarVetor(TVet *vetor, int tamanho);
void inicializarSequencial(TVet* vetor);
