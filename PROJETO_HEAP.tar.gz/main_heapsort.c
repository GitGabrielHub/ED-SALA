#include "projeto.h"

static GtkWidget* time_sequencial,* time_encadeado,* number1;
TlistaEnc listaEnc ;

void calcular_tempo (int T,char auxiliar[20]){
  int min,seg;
  char m[10],s[10],t[10];

  min = (T ) / 60;
  seg =  (int)(T) % 60;

  sprintf(m, "%i", min);
  sprintf(s, "%i", seg);

  if(min < 10){
    auxiliar[0] = '0';
    auxiliar[1] = m[0];
  }

  else {
    auxiliar[0] = m[0];
    auxiliar[1] = m[1];
  }

  auxiliar[2] = ' ';
  auxiliar[3] = ':';
  auxiliar[4] = ' ';

  if (seg < 10){
    auxiliar[5] = '0';
    auxiliar[6] = s[0];
  }

  else {
    auxiliar[5] = s[0];
    auxiliar[6] = s[1];
  }
  
}

void gerar_numeros (GtkWidget* boton1, gpointer data){
  int num1 = atoi((char *)gtk_entry_get_text(GTK_ENTRY(number1)));
  
  unsigned long int i;
  FILE *arquivo;
  arquivo = fopen("aleatorios.txt", "w");
  if(arquivo == NULL){
      printf("Arquivo nao pode ser aberto.\n");
      return;
  }

  if(listaEnc.lista != NULL){
    apagar_lista_encadeada(&listaEnc);
  }
  srand( (unsigned) time(NULL));
  int num;
  for(i=0; i<num1; i++){
    num = 1 + rand() % (num1 * 2);
    fprintf(arquivo, "%d ", num);   
  }
  
  fclose(arquivo);
}

void adicionar_encadeado(TlistaEnc* l){
  int num1 = atoi((char *)gtk_entry_get_text(GTK_ENTRY(number1)));

  unsigned long int i,y;
  unsigned long int valores[num1]; 

  FILE *arquivo1;
  arquivo1 = fopen("aleatorios.txt","r");
  if (arquivo1 == NULL) {
      printf("Arquivo nao pode ser aberto.\n");
      return;
  }
  int num;
  for (i=0;i<num1;i++){
    fscanf(arquivo1,"%ld",&valores[i]);
    add(&listaEnc,valores[i]);
  }
  
  fclose(arquivo1);
  imprimir(listaEnc);
}

void ordenar_encadeado (GtkWidget* boton1, gpointer data){
  unsigned long int i;
  FILE *arquivo;
  clock_t Inicio, Fim;

  adicionar_encadeado(&listaEnc);

  arquivo = fopen("ordenado.txt", "w");
  if(arquivo == NULL){
      printf("Arquivo nao pode ser aberto.\n");
      return;
  }

  srand( (unsigned) time(NULL));
  int num;

  Inicio = clock();
  HeapSort(&listaEnc, listaEnc.size);
  Fim = clock();
  
  no* aux = listaEnc.lista;
  while(aux != NULL){
    fprintf(arquivo, "%d ", aux -> dado); 
    aux = aux -> prox;
  }
  fclose(arquivo);
  imprimir(listaEnc);

  float tempo_final = (Fim - Inicio) / 1000000;
  char buffer[20];
  char tempo_encadeado[20];
  calcular_tempo(tempo_final,tempo_encadeado);
  
  snprintf(buffer, sizeof(buffer), "%s",tempo_encadeado);
  gtk_label_set_text(GTK_LABEL(time_encadeado), buffer);

}

int main(int argc, char **argv){

  inicializar(&listaEnc);

  GtkWidget * window,* grid,* boton1,* boton2,* boton3, * conteudo;

  gtk_init(&argc, &argv);

  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);
  gtk_container_set_border_width (GTK_CONTAINER (window), 10);
  gtk_window_set_title (GTK_WINDOW (window), "Programa");


  grid = gtk_grid_new();
  gtk_container_add(GTK_CONTAINER(window), grid);
  gtk_grid_set_row_spacing(GTK_GRID(grid),2.5);
  gtk_grid_set_column_spacing (GTK_GRID(grid),2.5);

  number1 = gtk_entry_new();
  gtk_grid_attach(GTK_GRID(grid), number1, 0, 0, 1, 1);

  boton1 = gtk_button_new_with_label("Gerar números aleatórios");
  g_signal_connect(boton1, "clicked", G_CALLBACK(gerar_numeros), NULL);
  gtk_grid_attach(GTK_GRID(grid), boton1, 1, 0, 1, 1);

  boton2 = gtk_button_new_with_label("Ordenar com lista encadeada");
  g_signal_connect(boton2, "clicked", G_CALLBACK(ordenar_encadeado), NULL);
  gtk_grid_attach(GTK_GRID(grid), boton2, 0, 1, 1, 1);

  boton3 = gtk_button_new_with_label("Ordenar com lista sequencial");
  g_signal_connect(boton3, "clicked", G_CALLBACK(gerar_numeros), NULL);
  gtk_grid_attach(GTK_GRID(grid), boton3, 1, 1, 1, 1);

  time_encadeado = gtk_label_new("TEMPO ENCADEADO");
  gtk_grid_attach(GTK_GRID(grid), time_encadeado, 0, 2, 1, 1);

  time_sequencial = gtk_label_new("TEMPO SEQUENCIAL");
  gtk_grid_attach(GTK_GRID(grid), time_sequencial, 1, 2, 1, 1);

  gtk_widget_show_all(window);
  gtk_main();

  return 0;

}